import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: QuizApp(),
    );
  }
}

class QuizApp extends StatefulWidget {
  const QuizApp({super.key});

  @override
  State<QuizApp> createState() => _QuizAppState();
}

class _QuizAppState extends State<QuizApp> {

  int questionIndex = 0;
  int score = 0;
  String? selectAnswer;
  bool answerChecked = false;
  bool quizFinished = false;
  String message = "";
  Color messageColor = Colors.black;

  final List<Map<String, dynamic>> questions =[
    {
      "question": "Quel langage est utilisé avec Flutter ?",
      "option": ["Java", "Dart", "Python"],
      "correctAnswer": "Dart"
    },
    {
      "question": "Qui a crée Flutter ?",
      "option": ["Apple", "Google", "Microsoft"],
      "correctAnswer": "Google"
    },
    {
      "question": "Dans quel langage Flutter est-il écrit ?",
      "option": ["Java", "Kotlin", "Dart"],
      "correctAnswer": "Dart"
    }
  ];

  @override
  Widget build(BuildContext context) {

    final currentQuestion = !quizFinished ? questions[questionIndex] : null;
    final totalQuestion = questions.length;
    final currentNumber = questionIndex + 1;
    final progress = currentNumber / totalQuestion;

    //check answer
    void checkAnswer(){
      if(selectAnswer == null){
        setState(() {
          message = "veuillez choisir une réponse.";
          messageColor = Colors.orange;
        });
        return;
      }

      setState(() {
        answerChecked = true;
        if(selectAnswer == questions[questionIndex]["correctAnswer"]){
          message = "Bonne réponse !";
          messageColor = Colors.green;
          score++;
        } else{
          message = "Mauvaise réponse !";
          messageColor = Colors.red;
        }
      });
    }

    //next question
    void nextQuestion(){
      setState(() {
        if(questionIndex<questions.length - 1){
          questionIndex++;
          selectAnswer = null;
          message = "";
          messageColor = Colors.black;
          answerChecked = false;

        }else{
          quizFinished = true;
        }
      });
    }

    //restartQuiz
    void restartQuiz(){
      setState(() {
        questionIndex = 0;
        score = 0;
        selectAnswer = null;
        message = "";
        messageColor = Colors.black;
        answerChecked = false;
        quizFinished = false;
      });
    }


    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: Text(
          "Mini Quiz",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: quizFinished
            ? Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Quiz terminé !",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 25,
                  color: Colors.deepPurple,
                  fontWeight: FontWeight.bold
                ),
              ),
              SizedBox(height: 20,),

              Text("Votre score : $score/${questions.length}",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87
                ),
              ),

              SizedBox(height: 20,),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)
                  )
                ),
                onPressed: restartQuiz, 
                child: Text(
                  "Rejouer",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold
                  ),
                )
              ),
            ],
          )
          : Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Question $currentNumber/$totalQuestion",
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.deepPurple,
                  fontWeight: FontWeight.bold,
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(50),
                child: LinearProgressIndicator(
                  value: progress,
                  minHeight: 10,
                  backgroundColor: Colors.deepPurple[100],
                  color: Colors.deepPurple,
                ),
              ),
              SizedBox(height: 8,),
              Text(
                currentQuestion!["question"],
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold
                ),
              ),
              SizedBox(height: 8,),
              ...List<String>.from(currentQuestion["option"]).map((opt){
                return RadioListTile<String>(
                  title: Text(opt),
                  value: opt,
                  groupValue: selectAnswer,
                  activeColor: Colors.deepPurple,
                  onChanged: (value) {
                    if(!answerChecked){
                      setState(() {
                        selectAnswer = value;
                      });
                    }
                  },
                );
              }),
              SizedBox(height: 8,),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))
                ),
                onPressed: (){
                  if(answerChecked){
                    nextQuestion();
                  }else{
                    checkAnswer();
                  }
                }, 
                child: Text(
                  answerChecked? "suivant" : "Vérifier",
                  style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold
                  ),
                )
              ),
              SizedBox(height: 8,),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  color: messageColor,
                  fontWeight: FontWeight.bold
                ),
              )
            ],
          )
        ),
      ),
    );
  }
}