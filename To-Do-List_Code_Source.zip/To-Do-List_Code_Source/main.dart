import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ToDoList(),
    );
  }
}

class ToDoList extends StatefulWidget {
  const ToDoList({super.key});

  @override
  State<ToDoList> createState() => _ToDoListState();
}

class _ToDoListState extends State<ToDoList> {

  final TextEditingController _controller = TextEditingController();
  final List<Task> _tasks = [];

  void _addTask(){
    if(_controller.text.isNotEmpty){
      setState(() {
        _tasks.add(Task(title: _controller.text));
        _controller.clear();
      });
    }
  }

  void _deleteTask(int index){
    setState(() {
      _tasks.removeAt(index);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: 
        Center(
          child: Text(
          "Tâche supprimée",
            style: TextStyle(color: Colors.red),
          ),
        )
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: Text(
          "To-Do List",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: "Ajouter une tâche",
                      hintStyle: TextStyle(color: Colors.grey[400]),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)
                      )
                    ),
                  )
                ),
                SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple
                  ),
                  onPressed: (){
                    _addTask();
                  }, 
                  child: Text(
                    "Ajouter",
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  )
                )
              ],
            ),
          ),
          Expanded(
            child: _tasks.isEmpty
              ? Center(
              child: Text(
                "Aucune tâche pour l'instant",
                style: TextStyle(color: Colors.grey[400]),
              ),
            )
            : ListView.builder(
              itemCount: _tasks.length,
              itemBuilder: (context, index){
                return Card(
                  child: CheckboxListTile(

                    title: Text(
                      _tasks[index].title,
                      style: TextStyle(
                        decoration: _tasks[index].isDone
                          ? TextDecoration.lineThrough
                          : TextDecoration.none
                      ),
                    ),

                    value: _tasks[index].isDone, 
                    onChanged: (value){
                      setState(() {
                        _tasks[index].isDone = value ?? false;
                      });
                    },
                    secondary: IconButton(
                      onPressed: (){
                        _deleteTask(index);
                      }, 
                      icon: Icon(Icons.delete, color: Colors.red,)
                    ),
                  ),
                );
              }
            )
          )
        ],
      ),
    );
  }
}

class Task{
  String title;
  bool isDone;

  Task({required this.title, this.isDone = false});
}